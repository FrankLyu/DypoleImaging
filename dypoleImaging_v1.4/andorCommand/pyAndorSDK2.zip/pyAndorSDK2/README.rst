Andor SDK2 python wrapper
=========================

API wrapper for SDK2 from Andor.
Supported platforms: python 3.7, python 3.8

----

Beta test python SDK2 wrapper
Contains wrapper interface and latest SDK libraries
Note the new package name to use in an import; all other wrapper use should be the same. (You can alias the import if you absolutely have to.)

Tested on Win 10 32- and 64-bit

Installation depending on your python installation:

Open command console (Windows):
> pip3 install .
> python3 –m pip install .

Also
> pip3 list
> pip3 uninstall pyAndorSDK2

'sudo' as necessary for Linux

Any errors or suggestions, please report.
